# def Fizz_Buzz(n):
#     for i in range (0 ,99):
#         if i % 3==0 and i% 5 == 0:
#             print("FizzBuzz")
#         elif i% 3 ==0:
#             print("Fizz")
#         elif i% 5 ==0:
#             print("Buzz")
#         else :
#             print(i)
# Fizz_Buzz(100)

# def Fizz_Buzz(input):
#     # for i in range (0 ,99):
#         if( input % 3==0) and (input % 5 == 0):
#             return "FizzBuzz"
#         elif input % 3 ==0:
#             return "Fizz"
#         elif input % 5 ==0:
#             return "Buzz"
#         else :
#             return input 
# Fizz_Buzz(10)

# number=int(input("enter the number"))
# if number % 3==0 and number % 5 == 0:
#     print("FizzBuzz")
# elif number % 3 ==0:
#     print("Fizz")
# elif number % 5 ==0:
#     print("Buzz")
# else :
#     print(number)

def play_fizzbuzz():
    print("welcome to fizzbuzz game!")
    print("player take turn to enter the number.")
    print("Type 'exist' to quit the game.")

    player_turn=1
    while True:
        user_input=input(f"player{player_turn} ,enter a number (or type 'exist' to quit the game):")
        if user_input.lower() == 'exist':
            print("game over.Thanks for playing game!")
            break
        try:
            number=int(user_input)
        except ValueError:
            print("invalid input .plz enter a valid number")
            continue
        
        if number % 3==0 and number % 5 == 0:
            print("FizzBuzz")
        elif number % 3 ==0:
            print("Fizz")
        elif number % 5 ==0:
            print("Buzz")
        else :
            print(number)
        
        player_turn=1 if player_turn == 2 else 2

play_fizzbuzz() 

        


