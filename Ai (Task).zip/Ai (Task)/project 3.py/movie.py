movies = [
    ("Eternal Sunshine of the Spotless Mind", 20000000),
    ("Memento", 9000000),
    ("Requiem for a Dream", 4500000),
    ("Pirates of the Caribbean: On Stranger Tides", 379000000),
    ("Avengers: Age of Ultron", 365000000),
    ("Avengers: Endgame", 356000000),
    ("Incredibles 2", 200000000)
]

def Calculate_average_budget(movies):
    total_budget=sum(budget for name, budget in movies)
    average_budget=total_budget/len(movies)
    return average_budget
def high_budget(movies,average_budget):
    high_budget_movies=[]
    for name,budget in movies:
        if budget>average_budget:
            high_budget_movies.append((name,budget))
            print("Movie with higher budget")
            print(f"{len(high_budget_movies)} movies have a higher budget than the average.")

    for name,budget in high_budget_movies:
        print(f"{name}:,${budget:,} (exclude average ${budget - average_budget:,})")
    return high_budget

def add_movies(movies):
    movies_add=int(input("how many movies would you like to add in it ...?"))
    for _ in range(movies_add):
        movies_name=input("enter movie name")
        movies_budget=int(input("enter movie budget"))
        movies.append((movies_name,movies_budget))
        print("update movie list")
    for movies_name,budget in movies:
        print(f"{movies_name}:{budget:,}")

add_movies(movies)
average_budget=Calculate_average_budget(movies)
print(f"average_budget:{average_budget:,}")
high_budget_list=high_budget(movies,average_budget)


        

