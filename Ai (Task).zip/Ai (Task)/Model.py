class ModelBaseAgent:
    def __init__(self,desired_temperature):
        self.desired_temperature=desired_temperature
        self.previous_action=[]
    def perceive(self,current_temperature):
        self.previous_action.append(current_temperature)
        return current_temperature
    def act(self,current_temperature):
        if current_temperature < self.desired_temperature and not self.previous_action:
            action="Turn on heater"
            self.previous_action.append("heater on")
        elif current_temperature >= self.desired_temperature and self.previous_action:
            action ="Turn off heater"
            self.previous_action.clear()
        else:
            action="No change"
        return action
rooms= {
    "Living Room": 17,
    "Bedroom": 26,
    "Kitchen":19,
    "Bathroom":24
}
desired_temperature=22
agent=ModelBaseAgent(desired_temperature)
for room ,temperature in rooms.items():
    current_temperature=agent.perceive(temperature)
    action=agent.act(current_temperature)
    print(f"{room}:current_temperature={temperature}°C. {action}.")