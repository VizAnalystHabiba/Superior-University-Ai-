pun=input("enter the string:")
usedate="./!@#$%^&*,:;'"
for j in pun:
    if j not in usedate:
        print(j,end="")