my_string=str(input("enter string: "))
alphabets=[alph.lower() for alph in my_string.split()]
alphabets.sort()
print("the sorted word are :")
for alph in alphabets:
    print(alph)

